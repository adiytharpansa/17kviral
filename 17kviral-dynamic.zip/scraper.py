import requests
from bs4 import BeautifulSoup
import json

url = "https://www.xvideos.com/new/indonesia"
headers = {"User-Agent": "Mozilla/5.0"}

r = requests.get(url, headers=headers)
soup = BeautifulSoup(r.text, "html.parser")

videos = []
for thumb in soup.select(".thumb-block"):
    title = thumb.select_one(".title").get_text(strip=True)
    href = thumb.select_one("a").get("href")
    embed_id = href.split("/video")[1].split("/")[0]
    embed = f"https://www.xvideos.com/embedframe/{embed_id}"
    thumb_url = thumb.select_one("img").get("data-src")
    duration = thumb.select_one(".duration").get_text(strip=True) if thumb.select_one(".duration") else "00:00"
    videos.append({ "title": title, "thumb": thumb_url, "embed": embed, "duration": duration })

with open("videos.json", "w") as f:
    json.dump(videos, f, indent=2)
